<?php

require_once 'ConexaoMysql.php';

/**
 * Description of usuarioModel
 *
 * @author user
 */
class usuariosModel {

    //put your code here
    protected $id;
    protected $nome_completo;
    protected $CPF;
    protected $data_nascimento;
    protected $genero;
    protected $email;
    protected $senha;

    public function getId() {
        return $this->id;
    }

    public function getNome_completo() {
        return $this->nome_completo;
    }

    public function getCPF() {
        return $this->CPF;
    }

    public function getData_nascimento() {
        return $this->data_nascimento;
    }

    public function getGenero() {
        return $this->genero;
    }

    public function getEmail() {
        return $this->email;
    }

    public function getSenha() {
        return $this->senha;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setNome_completo($nome_completo): void {
        $this->nome_completo = $nome_completo;
    }

    public function setCPF($CPF): void {
        $this->CPF = $CPF;
    }

    public function setData_nascimento($data_nascimento): void {
        $this->data_nascimento = $data_nascimento;
    }

    public function setGenero($genero): void {
        $this->genero = $genero;
    }

    public function setEmail($email): void {
        $this->email = $email;
    }

    public function setSenha($senha): void {
        $this->senha = $senha;
    }

    public function __construct() {
        
    }

    public function checkLogin() {
        $db = new ConexaoMysql();

        $db->Conectar();

        $sql = 'SELECT senha FROM usuarios WHERE email = "' . $this->email . '" AND'
                . ' senha = "' . $this->senha . '"';

        $db->Executar($sql);

        $db->Desconectar();

        return $db->total;
    }

    public function cadastrar() {
        $db = new ConexaoMysql();

        $db->Conectar();

        $sql = 'INSERT INTO usuarios VALUES (0,"' . $this->nome_completo . '",'
                . '"' . $this->CPF . '",'
                . '"' . $this->data_nascimento . '",'
                . '"' . $this->genero . '",'
                . '"' . $this->email . '",'
                . '"' . $this->senha . '")';

        $db->Executar($sql);

        $db->Desconectar();

        return $db->total;
    }

    public function loadUserId() {
        $db = new ConexaoMysql();

        $db->Conectar();

        $sql = 'SELECT id FROM usuarios WHERE email = "' . $this->email . '" AND'
                . ' senha = "' . $this->senha . '"';

        $user_id = $db->Consultar($sql);

        if ($db->total == 1) {
            foreach ($user_id as $value) {
                $this->id = $value['id'];
            }
        }

        $db->Desconectar();

        return $user_id;
    }

}
