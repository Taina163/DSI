<?php
require_once 'ConexaoMysql.php';
/**
 * Description of farmaciasModel
 *
 * @author user
 */
class farmaciasModel {
    protected $id;
    protected $numero;
    protected $endereco;
    
    public function getId() {
        return $this->id;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getEndereco() {
        return $this->endereco;
    }

    public function setId($id): void {
        $this->id = $id;
    }

    public function setNumero($numero): void {
        $this->numero = $numero;
    }

    public function setEndereco($endereco): void {
        $this->endereco = $endereco;
    }

    public function __construct() {
        
    }

    public function loadAll(){
        $db = new ConexaoMysql();
        
        $db->Conectar();
        
        $sql = 'SELECT * FROM farmacias';
        
        $resultList = $db->Consultar($sql);
        
        if($db->total == 1){
            foreach($resultList as $values){
            $this->id = $values['id'];
            $this->numero = $values['numero'];
            $this->endereco = $values['endereco'];
            }
        }
        
        $db->Desconectar();
        
        return $resultList;
    }
}
