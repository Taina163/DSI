<?php
require_once'./shared/headerShared.php';


?>
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8 border-bottom border-3">
                    <h2>Itens no carrinho:</h2>

                    <table id="myTable" class="display table-hover">
                        <thead>
                            <tr class="table-info">
                                <th>Lista de Produtos</th>
                                <th>Valor Produto</th>
                                <th>Retirar Produto</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            @session_start();
                            /* foreach ($_SESSION['carrinho'] as $mostrar) {
                              echo($mostrar);
                              } */

                            if (!empty($_SESSION['carrinho']) && $_SESSION['carrinho'] != null && isset($_SESSION['logado'])) {


                                //var_dump($_SESSION['carrinho']);

                                $whereIn = implode(',', $_SESSION['carrinho']);
                                require_once './model/produtosModel.php';
                                $produtos = new produtosModel();
                                $resultList = $produtos->loadWhereIn($whereIn);
                                $valor_total = 0;
                                $lista_produtos = "";
                                //if(!empty($_SESSION['carrinho'])){

                                foreach ($resultList as $values) {
                                    //foreach($_SESSION['carrinho'] as $ids){ //para poder exibir itens repetidos
                                    foreach ($_SESSION['carrinho'] as $ids) { //para poder exibir itens repetidos
                                        if ($ids == $values['id']) {
                                            echo('<tr>'
                                            . '<td>' . $values['nome'] . '</td>'
                                            . '<td>R$' . $values['preco_base'] . '</td>'
                                            . '<td><a href="controller/carrinhoController.php?delete=' . $values['id'] . '">Retirar</a></td>'
                                            . '</tr>');

                                            $valor_total = $valor_total + $values['preco_base'];
                                            if ($lista_produtos == "") {
                                                $lista_produtos = $lista_produtos . $values['nome'];
                                            } else {
                                                $lista_produtos = $lista_produtos . ", " . $values['nome'];
                                            }
                                        }
                                    }
                                }

                                echo('</tbody>');
                                echo('<tfoot>');
                                echo('<tr>');
                                echo('<th></th>');
                                echo('<th colspan="2" style="text-align:right">Valor Total: R$' . $valor_total . '</th>');

                                echo('</tr>');
                                echo('</tfoot>');
                                echo(' </table>');
                                echo('</div>');
                                echo('<div class="col-md-2"></div>');
                                echo('</div>');

                                
                                
                            }else{
                                echo('<div class="alert alert-danger">'
                                        . 'Logue em sua conta para poder adicionar itens ao carrinho!'
                                        . '</div>');
                            }
                                
                            ?>

                            </div>
                <div class="row">
                               <div class="col-md-2"></div>
                                <div class="col-md-4">
                                
                                <form method="post" action="controller/carrinhoController.php">
                                <div class="mb-3 mt-3">
                                <select class="form-select" required name="farmacias_id">
                                    
                                    <?php
                                    require_once './model/farmaciasModel.php';
                                    $farmacias = new farmaciasModel();
                                    $farmaciasList = $farmacias->loadAll();
                                    
                                    foreach($farmaciasList as $option){
                                        
                                echo('<option>Farmacia '.$option['numero'].','.$option['endereco'].'</option>');
                                    }
                                    ?>
                                </select>
                                </div>
                                <div class="mb-3 mt-3">
                                <label for="frete" class="form-label">Insira seu CEP</label>
                                <input type="text" class="form-control" id="frete" name="frete"
                                 maxlength="8" minlength="8">
                                <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t">Não sabe o CEP?</a>
                                </div>
                                    
                                </div>
                                <div class="col-md-4">
                                    <input type="submit" value="Finalizar compra" class="btn btn-success w-100 mt-5">
                                </form>
                                </div>
                                <div class="col-md-2"></div>
                            </div>
                            </body>
                            </html>
