<html>
    <head>
        <meta charset="UTF-8">
        <title>Últimas Compras</title>
        <link href="css/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_css_bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_js_bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/code.jquery.com_jquery-3.7.1.min.js" type="text/javascript"></script>
        <link href="css/cdn.datatables.net_1.13.6_css_jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/cdn.datatables.net_1.13.6_js_jquery.dataTables.min.js" type="text/javascript"></script>

        <script>
            $(document).ready(function () {
                $('#myTable').DataTable();
            });
        </script>

    </head>
    <body class="container">
        <nav class="navbar navbar-expand-md bg-primary-subtle">
            <div class="container-fluid">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-info">Voltar</a>
                    </li>
                </ul>

            </div>
        </nav>
        <div class="row">
            <div class="col-md-12">
                <table id="myTable" class="display">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Lista de Produtos</th>
                            <th>Valor Total</th>
                            <th>Farmácia da Compra</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once './controller/ultimasComprasController.php';
                        ?>  
                    
                    </tbody>
                </table>
            </div>

        </div>



    </body>
</html>
