<?php
require_once './model/comprasModel.php';
@session_start();
$ultimas = new comprasModel();

$results = $ultimas->loadAll(json_encode($_SESSION['id']));

foreach ($results as $values){
    echo('<tr>'
            . '<td>'.$values['data'].'</td>'
            . '<td>'.$values['lista_produtos'].'</td>'
            . '<td>R$'.$values['valor_total'].'</td>'
            . '<td>'.$values['farmacias_id'].'</td>'
            . '</tr>');
}

?>