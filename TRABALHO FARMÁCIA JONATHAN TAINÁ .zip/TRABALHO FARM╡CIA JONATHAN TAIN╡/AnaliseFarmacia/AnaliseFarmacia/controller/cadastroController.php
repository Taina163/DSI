<?php
if($_POST){
//verificação de cpf
    /*
if ($cpf != "") {
    $a= substr("$cpf", 0,3);
    $b= substr("$cpf", 4,3);
    $c1= substr("$cpf", 8,3);
    $d= substr("$cpf", 12,2);
    $CPF=$a.$b.$c1.$d;

    $s = $CPF;
    $c =  substr("$s", 0,9);
    $dv = substr("$s", 9,2);
    $d1 = 0;
    for ($i = 0; $i < 9; $i++) {
        $d1 += $c[$i]*(10-$i);
    }

    if ($d1 == 0) {
        $v=1;
        $result = "invalid";
    }

    $d1 = 11 - ($d1 % 11);
    if ($d1 > 9) {
        $d1 = 0;
    }
    if ($dv[0] != $d1) {
        $v=$v+1;
        $result = "invalid";
    }

    $d1 *= 2;
    for ($i = 0; $i < 9; $i++) {
        $d1 += $c[$i]*(11-$i);
    }
    $d1 = 11 - ($d1 % 11);
    if ($d1 > 9) {
        $d1 = 0;
    }
    if ($dv[1] != $d1) {
        $v=$v+1;
        $result = "invalid";
    }

    if ($v == "") {
        $result = "valid";
    }
}*/

//cadastro em si
//if($result == "valid"){
    if($_POST['senha']==$_POST['senhaConfirm']){
    require_once '../model/usuariosModel.php';
    $user = new usuariosModel();
    $user->setEmail($_POST['email']);
    $user->setSenha($_POST['senha']);
    $user->setCPF($_POST['cpf']);
    $user->setGenero($_POST['genero']);
    $user->setNome_completo($_POST['nome']);
    $user->setData_nascimento($_POST['nascimento']);
    
    $cadastro = $user->cadastrar();
    
    if($cadastro == 1){
        header('location:../cadastroLogin.php?cod=success');
    }else{
        header('location:../cadastroLogin.php?cod=error');
    }
}else{
    header('location:../cadastroLogin.php?cod=errorSenha');
}}
?>
