<html>
    
    <head>
        <meta charset="UTF-8">
        <title>Cadastro e Login</title>
        <link href="css/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_css_bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_js_bootstrap.bundle.min.js" type="text/javascript"></script>

    </head>
    <body>
        <nav class="navbar navbar-expand-md bg-info-subtle ">
            <div class="container-fluid">
                <ul class="navbar-nav">
                    <li class="nav-item m-5 justify-content-end">
                        <a href="index.php" class="nav-link btn btn-info border border-black">Home</a>
                    </li>
                    
                </ul>
            </div>
        </nav>
        
        
        <div class="container">
        <div class="row m-5">
            <div class="col-md-1"></div>
            <div class="col-md-4">
                
                <div class="border border-black border-5 border-success rounded-3 p-4">
                    <h2>Login</h2>
                    <form method="post" action="controller/loginController.php">
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="email" name="email" class="form-control"
                                   placeholder="Insira seu email" required>
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="senha" class="form-label">Senha:</label>
                            <input type="password" id="senha" name="senha" class="form-control"
                                   placeholder="Insira sua senha" required>
                        </div>
                        <input type="submit" class="btn btn-success" value="Logar">
                    </form>
                </div>
                <?php
                
                
                @$cod = $_REQUEST['cod'];
                
                  
                       
                if (isset($cod)) {
                    if ($cod == 'logSuccess') {
                        echo('<div class="alert alert-success">');
                        echo('<p>Login realizado com sucesso!</p>');
                        
                        echo('</div>');
                    }
                    if ($cod == 'logError') {
                        echo('<div class="alert alert-danger">');
                        echo('<p>Ocorreu um erro!</p>');
                        echo('</div>');
                    }
                }
                ?>
            </div>




            <div class="col-md-2"></div>
            <div class="col-md-4">
                <div class="border border-black border-5 border-success rounded-3 p-4">
                    <form method="post" action="controller/cadastroController.php">
                        <h2>Cadastro:</h2>
                        <div class="mb-3 mt-3">
                            <label for="nome" class="form-label">Nome completo:</label>
                            <input type="text" id="nome" name="nome" class="form-control"
                                   placeholder="Insira seu nome completo" required>
                        </div>

                        <div class="mb-3 mt-3">
                            <label for="cpf" class="form-label">CPF:</label>
                            <input type="text" id="cpf" name="cpf" class="form-control"
                                   placeholder="Insira seu CPF" required maxlength="11" minlength="11" size="15"
                                   >
                        </div>


                        <div class="mb-3 mt-3">
                            <label for="nascimento" class="form-label">Data de nascimento:</label>
                            <input type="date" id="nascimento" name="nascimento" class="form-control"
                                   placeholder="Insira sua data de nascimento" required>
                        </div>

                        <label for="genero" class="form-label mx-2">Gênero:</label>
                        <div class="btn-group">
                            <div class="form-check mx-1" id="genero">
                                <input type="radio" class="form-check-input" id="fem" name="genero" value="F">
                                <label class="form-check-label" for="fem">Feminino</label> 
                            </div>
                            <div class="form-check mx-1">
                                <input type="radio" class="form-check-input" id="masc" name="genero" value="M">
                                <label class="form-check-label" for="masc">Masculino</label> 
                            </div>
                        </div>

                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" id="email" name="email" class="form-control"
                                   placeholder="Insira seu email" required>
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="senha" class="form-label">Senha:</label>
                            <input type="password" id="senha" name="senha" class="form-control"
                                   placeholder="Insira sua senha" required>
                        </div>
                        <div class="mb-3 mt-3">
                            <label for="senhaConfirm" class="form-label">Confirmar senha:</label>
                            <input type="password" id="senhaConfirm" name="senhaConfirm" class="form-control"
                                   placeholder="Repita a senha inserida acima" required>
                        </div>
                        <input type="submit" class="btn btn-success" value="Cadastrar">
                    </form>
                </div>
                <?php
                @$cod = $_REQUEST['cod'];
                if (isset($cod)) {
                    if ($cod == "success") {
                        echo('<div class="alert alert-success">');
                        echo('<p>Cadastro realizado com sucesso!</p>');
                        echo('</div>');
                    }
                    if ($cod == "error") {
                        echo('<div class="alert alert-danger">');
                        echo('<p>Ocorreu um erro, cadastro não realizado.</p>');
                        echo('</div>');
                    }
                    if ($cod == "errorSenha") {
                        echo('<div class="alert alert-danger">');
                        echo('<p>Senhas diferentes.</p>');
                        echo('</div>');
                    }
                }
                ?>
            </div>


            <div class="col-md-1"></div>

        </div>
        </div>
    </body>
</html>
