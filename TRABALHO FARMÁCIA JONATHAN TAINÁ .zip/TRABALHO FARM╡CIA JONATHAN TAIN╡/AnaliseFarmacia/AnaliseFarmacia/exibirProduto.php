
        <?php
        require_once'./shared/headerShared.php';
        

if ($_REQUEST['id']) {
    require_once 'model/produtosModel.php';
    $produto = new produtosModel();
    $result = $produto->loadById($_REQUEST['id']); //chama o id do produto

    echo('<div class="container">');
    
    echo ('<div class="row">');
    foreach ($result as $produtos) {



        echo('<div class="col-md-6">');
        echo('<h2>' . $produtos['nome'] . '</h2>');
        echo('<p>' . $produtos['descricao'] . '</p>');
        echo('<h4>Valor: R$' . $produtos['preco_base'] . '</h4>');
        echo('<a class="d-grid btn btn-info"'
                . 'href="controller/carrinhoController.php?id=' . $produtos['id'] . '"'
                . '>Adicionar ao carrinho</a>');
        echo('</div>');
        echo('<div class="col-md-6">');
        echo('<img src="' . $produtos['imagem'] . '" class="border border-2 w-100 h-100">');
        echo('</div>');
    }

    echo ('</div>');

    echo('</div>');
}
?>
    </body>
</html>
