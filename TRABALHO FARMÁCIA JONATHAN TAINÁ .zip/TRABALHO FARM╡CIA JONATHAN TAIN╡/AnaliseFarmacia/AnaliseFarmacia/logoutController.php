<?php
if($_REQUEST){
    @session_start();
    @session_abort();
    @session_destroy();
    header('location: ../index.php');
}
?>

