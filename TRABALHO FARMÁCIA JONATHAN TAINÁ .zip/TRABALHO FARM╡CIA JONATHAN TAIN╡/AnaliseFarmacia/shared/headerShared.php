<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Farmácia</title>
        <link href="css/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_css_bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/cdn.jsdelivr.net_npm_bootstrap@5.3.2_dist_js_bootstrap.bundle.min.js" type="text/javascript"></script>
        <script src="js/code.jquery.com_jquery-3.7.1.min.js" type="text/javascript"></script>
        <link href="css/cdn.datatables.net_1.13.6_css_jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
        <script src="js/cdn.datatables.net_1.13.6_js_jquery.dataTables.min.js" type="text/javascript"></script>

        <script>
            $(document).ready(function () {
                $('#myTable').DataTable();
            });
        </script>

    </head>
    <body>

        <nav class="navbar justify-content-md-end navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">
                <a class="navbar-brand float-left" href="#">
                    <img src="img/Logo.png" alt="Logo da JT Farmácias" style="width:50px;height:50px;" >
                    <span class="navbar-text">Farmácias JT</span>
                </a>
                
            </div>
            
            <form class="d-flex navbar-expand">
                <input class="form-control m-2 " type="text"/>
                <button class="btn btn-primary m-2" type="button">Pesquisar</button>
            </form>
            
            

              <?php
              @session_start();
              if(isset($_SESSION['logado'])){
            echo('<a href="controller/logoutController.php?cod=logout" class="navbar-brand btn btn-outline-danger mx-2 cleafix float-end">Logout</a>');
            }else{  
              echo('<a class="navbar-brand btn btn-outline-light " href="cadastroLogin.php">
                  
                    <img src="img/conta.png" alt="alt" style="width:50px;height:50px;" class=" rounded-pill">
                    Entrar
            </a>');}
                            ?>
            

           
                <a class="navbar-brand btn btn-outline-light" href="carrinho.php">
                    <img src="img/carrinho.png" alt="alt"  style="width:50px;height:50px;" class=" ">
                    Carrinho
                </a>
                
            
            

            
        </nav>
        
        
        <nav class="navbar navbar-expand-lg bg-opacity-75 bg-black ">
            <a class="navbar-brand btn btn-outline-light" href="index.php">
                    <img src="img/Casinha.png" alt="alt"  style="width:50px;height:50px;" class=" ">
                    
                </a>
            <button class="navbar-brand btn btn-outline-info text-white mx-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#demo">
  Abrir filtragem
</button>
            <?php
             @session_start();
            
            
            if(isset($_SESSION['id'])){
                echo('<a class="navbar-brand btn btn-outline-light mx-2 text-white" href="ultimasCompras.php">
                    
                    Últimas compras
                </a>');
            }
        ?>
                    </nav>


        <div class="offcanvas offcanvas-start " id="demo">
            <div class="bg-black text-white offcanvas-header">
                <h1 class="offcanvas-title ">Categorias</h1>
                <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body text-black">
                
                    <div class="dropdown">
                        <div class="my-2  dropdown text-black">
                            <a class="btn btn-info dropdown-toggle" href="#" id="navbarDropdown"  data-bs-toggle="dropdown" >
                                Dermocosmeticos

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="index.php?subid=1">Creme Hidratante</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=2">Desodorante</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=3">Protetor Solar</a></li>
                            </ul>
                        </div>

                        <div class="my-2  dropdown">
                            <a class="btn btn-info dropdown-toggle" href="#" id="navbarDropdown"  data-bs-toggle="dropdown" >
                                Medicamentos
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="index.php?subid=4">Alergia e Infecções</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=5">Dor e Febre</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=6">Gripes e Refriados</a></li>
                            </ul>
                        </div>

                        

                        <div class="my-2  dropdown">
                            <a class="btn btn-info dropdown-toggle" href="#" id="navbarDropdown"  data-bs-toggle="dropdown" >    
                                Infantil e Gestante
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="index.php?subid=7">Alimentação</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=8">Cuidado com Bebê</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=9">Higiene Bucal</a></li>
                            </ul>
                        </div>
                        
                        <div class="my-2 dropdown">
                            <a class="btn btn-info dropdown-toggle" href="#" id="navbarDropdown"  data-bs-toggle="dropdown" >    
                                Medicamentos
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="index.php?subid=10">Aparelhos</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=11">Primeiros Socorros</a></li>
                                <li><a class="dropdown-item" href="index.php?subid=12">Diabetes</a></li>
                            </ul>
                        </div>
                
            </div>



        </div>
        </div>

