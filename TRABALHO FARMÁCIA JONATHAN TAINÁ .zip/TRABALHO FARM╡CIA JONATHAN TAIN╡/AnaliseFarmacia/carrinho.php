<?php
require_once'./shared/headerShared.php';
?>
<div class="container">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 border-bottom border-3">
            <h2>Itens no carrinho:</h2>

            <table id="myTable" class="display table-hover">
                <thead>
                    <tr class="table-info">
                        <th>Lista de Produtos</th>
                        <th>Valor Produto</th>
                        <th>Retirar Produto</th>
                    </tr>
                </thead>
                <tbody>
<?php

require_once'./controller/exibirTabelaCarrinho.php';


                
                    
               echo(' <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-4">

                        <form method="post" action="controller/carrinhoController.php">
                            <input type="hidden" name="lista_produtos" value="'.@$lista_produtos.'">
                            

                            <input type="hidden" name="valor_total" value="'. @$valor_total.'">
                           
                            <div class="mb-3 mt-3">

                                <select class="form-select" required name="farmacias_id">');


require_once './model/farmaciasModel.php';
$farmacias = new farmaciasModel();
$farmaciasList = $farmacias->loadAll();

foreach ($farmaciasList as $option) {

    echo('<option value="'.$option['id'].'">Farmacia ' . $option['numero'] . ',' . $option['endereco'] . '</option>');
}

                                echo('</select>');?>
                            </div>
                            <div class="mb-3 mt-3">
                                <label for="frete" class="form-label">Insira seu CEP</label>
                                <input type="text" class="form-control" id="frete" name="frete"
                                       maxlength="8" minlength="8">
                                <a href="https://buscacepinter.correios.com.br/app/endereco/index.php?t">Não sabe o CEP?</a>
                            </div>

                    </div>
                    <div class="col-md-4">
                        <input type="submit" value="Finalizar compra" class="btn btn-success w-100 mt-5">
                        </form>
                    </div>
                    <div class="col-md-2"></div>
                </div>
                </body>
                </html>
