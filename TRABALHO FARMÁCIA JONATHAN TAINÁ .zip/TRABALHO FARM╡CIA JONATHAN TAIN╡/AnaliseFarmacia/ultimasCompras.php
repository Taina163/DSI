<?php
require_once'./shared/headerShared.php';
?>
<div class="container">
        <div class="row">
            <div class="col-md-12">
                <table id="myTable" class="display">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Lista de Produtos</th>
                            <th>Valor Total</th>
                            <th>Farmácia da Compra</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        require_once './controller/ultimasComprasController.php';
                        ?>  
                    
                    </tbody>
                </table>
            </div>

        </div>
</div>
    </body>
</html>
